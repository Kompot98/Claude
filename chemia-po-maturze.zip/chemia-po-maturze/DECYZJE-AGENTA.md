# Decyzje agenta

Format wpisu: co, dlaczego, co odrzucone. Wpisów nie kasuję; zmianę zapisuję nowym wpisem.

## D-01, 2026-11-03: układ rejestrów i słowniki wartości

**Co:** `zasoby.csv` ma kolumny ze zlecenia. Wartości słownikowe: `rodzaj` z listy zlecenia; `poziom` ∈ {wprowadzenie, pierwszy rok, dalej}; `przedmiot` ∈ {ogólna i nieorganiczna, organiczna, fizyczna, analityczna, biochemia, matematyka, ogólne, spektroskopia, chemia kwantowa, laboratorium}; `dla_kierunkow` jako lista po średniku z {wszystkie, chemia, medycyna, stomatologia, weterynaria, farmacja, analityka medyczna, biotechnologia, inżynieria}. `zrodla.csv`: `id,typ,tytul,url,uczelnia,kierunek,przedmiot,rok_akademicki,data_odczytu,kopia_lokalna,uwagi`, typ ∈ {sylabus, program studiów, katalog, podręcznik, strona, publikacja}. Identyfikatory rysunków `F-001`.
**Dlaczego:** stałe słowniki pozwalają skryptowi wyłapać literówki i dają odbiorcy filtrowanie bez czyszczenia danych. Trzy dodatkowe wartości przedmiotu (spektroskopia, chemia kwantowa, laboratorium) są dla zasobów z rozdziału 4.
**Odrzucone:** wolny tekst w tych kolumnach.

## D-02, 2026-11-03: folder `robocze/` z dowodami

**Co:** każdy zasób ma plik `robocze/dowody/R-xxx.txt` z adresem, datą, metodą i surowymi danymi, z których powstał opis (lista filmów w playliście, fragmenty podstron, wpis katalogu). Tam też listy kandydatów z werdyktem, notatki z lektur do rozdziału 4 i zapis drugiego przeglądu. Folder zostaje w archiwum, w tekście bonusu nie jest cytowany.
**Dlaczego:** zlecenie wymaga, żeby opis nie powstał z pamięci; plik dowodu pozwala to sprawdzić bez powtarzania pracy.
**Odrzucone:** trzymanie dowodów tylko w kolumnie `uwagi` (za mało miejsca na listę filmów).

## D-03, 2026-11-03: dodatkowy folder `zlecenie/`

**Co:** kopie `ZLECENIE-agent-w-chmurze.md` i `KONTEKST-KaNaU.md` w archiwum.
**Dlaczego:** archiwum ma być samowystarczalne; odbiorca widzi, według jakiej wersji zlecenia powstał szkic.
**Odrzucone:** nic.

## D-04, 2026-11-03: wideo opisuję z tytułów filmów, bez transkrypcji

**Co:** dla playlist YouTube dowodem jest pełna lista tytułów filmów z długościami, pobrana bez logowania, oraz opis playlisty, gdy jest. Transkrypcji i opisów pojedynczych filmów to środowisko nie pobiera (YouTube żąda logowania), więc w `uwagi` każdego zasobu wideo piszę, z czego powstał opis.
**Dlaczego:** zlecenie zabrania logowania i opisów z pamięci; tytuły całej playlisty wystarczają, żeby opisać zakres i kolejność tematów, ale nie styl tłumaczenia.
**Odrzucone:** logowanie do YouTube (zabronione zleceniem); opisywanie stylu filmów z pamięci.

## D-05, 2026-11-03: OpenStax nie jest już źródłem rysunków (licencja NC)

**Co:** rysunków z OpenStax nie używam. Jedynym źródłem gotowych rysunków jest Wikimedia Commons z licencją sprawdzoną przy pliku. Teksty OpenStax nadal czytam i cytuję jako źródło (komentarze w rozdziale 4) i polecam jako otwarte podręczniki.
**Dlaczego:** zlecenie zakłada, że OpenStax to CC BY 4.0. W dniu sprawdzenia strony książek „Chemistry 2e”, „Chemistry: Atoms First 2e”, „Organic Chemistry” i „College Success” oraz API OpenStax podają licencję CC BY-NC-SA 4.0 („Textbook content produced by OpenStax is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike License”, stopka z lipca 2026). NC wyklucza użycie w płatnym kursie. Starsze wersje mogły być na CC BY; czy ta licencja nadal obowiązuje dla wcześniej pobranych kopii, to pytanie prawne, którego nie rozstrzygam.
**Odrzucone:** używanie rysunków OpenStax na podstawie starszej licencji. Pytanie do zleceniodawcy w raporcie.

## D-06, 2026-11-03: format rozdziału 3 po pilotażu

**Co:** (1) Nagłówki: `## Skąd się uczyć` dla wstępu, `## <przedmiot>` dla każdego przedmiotu, `### <rodzaj zasobu>` w środku, bo zlecenie dopuszcza tylko `##` i `###`, a podział jest dwupoziomowy. (2) Każdy zasób to akapit: nazwa i `[R-xxx]`, dwa, trzy zdania co w środku, zdanie „kiedy sięgnąć”, na końcu w nawiasie język i poziom. Bez tabel. (3) Kolejność rodzajów: polskie materiały uczelni, podręczniki, kanały wideo, strony i artykuły. Polskie pierwsze, bo zlecenie każe szukać najpierw po polsku. (4) Zasoby bliźniacze (dwie playlisty jednego autora) mogą dzielić akapit, ale każdy ma własne `[R-xxx]`. (5) Na początku przedmiotu krótki akapit, co się zmienia względem matury, bez twierdzeń o sylabusach, dopóki nie ma ich w `zrodla.csv`.
**Dlaczego:** akapit mieści trzy zdania i „kiedy sięgnąć”, czego tabela nie uniesie; stały szablon pozwala czytać wybiórczo.
**Odrzucone:** tabela zasobów; podział najpierw według rodzaju, potem przedmiotu (zlecenie mówi odwrotnie).

## D-07, 2026-11-03: adres płatnego podręcznika w rejestrze

**Co:** w kolumnie `url` przy płatnych podręcznikach polskich jest adres rekordu w API Biblioteki Narodowej (data.bn.org.pl), przy angielskich strona wydawcy. W tekście książka jest podana tytułem, autorem, wydaniem i wydawcą.
**Dlaczego:** BN nie ma stabilnej strony rekordu dla człowieka, a strony PWN i OUP odpowiadają automatom kodem 403. Rekord BN jest sprawdzalnym dowodem wydania. Przy wydaniu można podmienić adres na stronę wydawcy albo katalog biblioteki.
**Odrzucone:** linkowanie do księgarń (oferty się zmieniają, wygląda jak reklama).

## D-08, 2026-11-03: opisy pojedynczych filmów bywają dostępne (uzupełnienie D-04)

**Co:** strona pojedynczego filmu YouTube pobrana zwykłym zapytaniem zawiera opis i datę publikacji, ale YouTube szybko odpowiada kodem 429. Opis filmu pobieram tam, gdzie się uda, i zapisuję w dowodzie; reszta opisów wideo opiera się na pełnych listach tytułów. Transkrypcji nie pobieram.
**Dlaczego:** tak wyszło przy wykładach prof. Polańskiego (opis wykładu 1 i ukryta playlista odczytane ze strony filmu).
**Odrzucone:** obchodzenie limitu (wielokrotne ponawianie w krótkim czasie).

## D-09, 2026-11-03: format rozdziału 4 po pilotażu spektroskopii

**Co:** (1) Układ każdego wprowadzenia: `## <temat>`, krótki akapit otwierający (zdanie Adriana z punktu 9 i, gdzie pasuje, fakt z jego życiorysu), potem `### Czym to jest`, `### Dlaczego to spotkasz`, część merytoryczna (`### Co widać w widmie i po co` albo odpowiednik), `### Skąd uczyć się dalej`. (2) Komentarz źródłowy stoi po zdaniu albo po grupie zdań opartych na tym samym miejscu źródła, w formie `<!-- Z-001: 13.6, akapit o bromoetanie -->`. Identyfikator `Z-xxx` wskazuje wiersz w `zrodla.csv`, a dalej podrozdział i miejsce. (3) Każde wprowadzenie kończy się widocznym zdaniem „Źródła tego wprowadzenia: … [Z-xxx]”, żeby źródła były cytowane także w tekście, a nie tylko w komentarzach. (4) Przeczytane podrozdziały źródeł otwartych leżą w `zrodla/lektury/` jako tekst, żeby chemik sprawdzający rozdział miał je pod ręką. (5) Przykład wyprowadzony przeze mnie z tabeli źródła (alkohol i aldehyd w IR) jest oznaczony w komentarzu jako własny.
**Dlaczego:** zlecenie wymaga, żeby każde zdanie merytoryczne dało się sprawdzić w podanym miejscu; podrozdział plus akapit skraca to sprawdzenie do minuty.
**Odrzucone:** komentarz po każdym pojedynczym zdaniu (przy trzech zdaniach z jednego akapitu źródła trzy identyczne komentarze nic nie wnoszą).

## D-10, 2026-11-03: długość wprowadzenia o spektroskopii

**Co:** 04c ma około 4,8 strony zamiast 2–3. Zostawiam.
**Dlaczego:** spektroskopia to w praktyce cztery metody (MS, IR, NMR, UV-Vis), a UV-Vis ma dwa różne zastosowania (budowa w organicznej, stężenie w analityce). Skrócenie do trzech stron oznaczałoby wyrzucenie jednej metody albo zastosowania analitycznego, które dotyczy kierunków medycznych. Część o zasobach zajmuje około jednej strony.
**Odrzucone:** pominięcie spektrometrii mas (jest w podręcznikach organicznej obok IR i NMR) albo przeniesienie zasobów do rozdziału 3 (zlecenie chce „skąd uczyć się dalej” w każdym wprowadzeniu).

## D-11, 2026-11-03: niepełny łańcuch certyfikatów na serwerach uczelni

**Co:** część serwerów uczelni (sylabus.uj.edu.pl, sylabus.sggw.edu.pl, www.pum.edu.pl) wysyła tylko własny certyfikat, bez pośredniego. Przeglądarki dociągają brakujący certyfikat same z adresu zapisanego w certyfikacie (AIA). Zrobiłem to samo: pobrałem certyfikat pośredni z adresu AIA (np. GEANT TLS RSA 1 z crt.harica.gr) i dołączyłem go do pakietu zaufanych urzędów używanego przez curl. Weryfikacja TLS pozostała włączona przez cały czas.
**Dlaczego:** bez tego nie dało się pobrać sylabusów UJ i SGGW, a to strony publiczne, które uczeń otworzy w przeglądarce bez problemu.
**Odrzucone:** wyłączenie weryfikacji certyfikatów.

## D-12, 2026-11-03: zakres zbioru sylabusów

**Co:** 22 źródła dla ośmiu kierunków, po dwie, trzy uczelnie. Tam, gdzie pełny sylabus był niedostępny, użyłem planu studiów albo listy przedmiotów z godzinami i ECTS (typ „program studiów” w `zrodla.csv`). Na kierunkach medycznych plan jest zresztą ważniejszy od pojedynczego sylabusu, bo pokazuje, czy chemia w ogóle jest na pierwszym roku. Kopie lokalne to tekst wyciągnięty z PDF lub DOCX, z nagłówkiem; długie dokumenty skrócone do 40 000 znaków.
**Dlaczego:** zlecenie traktuje 24 zestawy jako górną granicę i każe zapisywać braki zamiast szukać bez końca.
**Odrzucone:** opieranie się na pojedynczych sylabusach II roku (UWr, UKSW organiczna, PP organiczna), które wyszły w wyszukiwaniu; nie dotyczą pierwszego roku.

## D-13, 2026-11-03: rysunki tylko jako opisy

**Co:** w `rysunki/` nie ma plików, `rysunki.csv` ma sam nagłówek. W tekście jest siedem opisów `[RYSUNEK: …]` do narysowania u zleceniodawcy.
**Dlaczego:** OpenStax jest w 2026 na licencji NC (D-05), LibreTexts w użytych książkach też (CC BY-NC-SA, CC BY-NC) albo bez zadeklarowanej licencji, a Wikimedia Commons przez cały etap odpowiadała temu środowisku kodem 429, więc licencji pojedynczych plików nie dało się sprawdzić. Zlecenie każe w takiej sytuacji niczego nie wstawiać. Jedyne użyte źródło z licencją pozwalającą na rysunki to podręcznik Peveratiego (CC BY-SA 4.0); jego rysunki nie odpowiadają żadnemu z opisów.
**Odrzucone:** rysunki z OpenStax i LibreTexts (NC), pliki z Commons bez sprawdzonej licencji, własne rysunki agenta (zlecenie przewiduje, że brakujące rysunki rysuje zespół zleceniodawcy w stylu kursu).

## D-14, 2026-11-03: długość i rozdział 5

**Co:** rozdziały 0–4 mają około 39 stron znormalizowanych, rozdział 5 (listy źródeł) około 21 stron. Rozdział 3 ma 14,6 strony, w środku przedziału 12–20. Wprowadzenia z rozdziału 4 mają 2,9–4,7 strony; spektroskopia jest dłuższa (D-10). Rozdział 5 jest generowany skryptem `skrypty/zrodla_md.py` z obu rejestrów i po każdej zmianie rejestrów trzeba go wygenerować ponownie.
**Dlaczego:** zlecenie chce przy każdej pozycji „co z tego wzięliśmy” i podziału na rozdziały; przy 93 pozycjach daje to długą listę. Dla czytelnika to dodatek do przeglądania, nie do czytania po kolei.
**Odrzucone:** skracanie opisów w rozdziale 5 poniżej jednego zdania (traci się informację, po co pozycja jest).

## D-15, 2026-11-03: serwisy z zabezpieczeniem antybotowym opisane z wyników wyszukiwarki

**Co:** Khan Academy (polski kurs „Chemia organiczna”, R-062) i Chemistry World (R-063) blokują automaty. Próba wejścia na Chemistry World inną drogą (kanał RSS, archiwum stron) została zablokowana przez zabezpieczenia środowiska jako obchodzenie testów antybotowych; nie ponawiałem jej ani podobnych. Oba zasoby opisałem z wyników wyszukiwarki (tytuły, adresy i fragmenty stron z indeksu), z adnotacją w `uwagi` i w pliku dowodu. Opis jest ogólniejszy niż przy zasobach otwartych bezpośrednio.
**Dlaczego:** zleceniodawca poprosił o próbę innych dróg; wyszukiwarka jest drogą zwykłą i jawną. Obchodzenie zabezpieczeń serwisu nie jest.
**Odrzucone:** pobieranie stron przez pośredników, archiwa i kanały techniczne w celu ominięcia blokady.

## D-16, 2026-11-03: odpowiedzi na pytania z raportu (decyzja zleceniodawcy: „zgodnie z rekomendacjami”)

**Co:** (1) Rysunków z OpenStax nie używamy; wszystkie brakujące rysunki są wstawkami `[RYSUNEK]` dla agenta od obrazków. (2) Chemistry World dopisany jako jedno hasło w rozdziale 3, przy chemii ogólnej, w części „Strony, artykuły i bazy danych” (R-063). (3) Polski kurs Khan Academy „Chemia organiczna” dopisany jako polski materiał w rozdziale 3 (R-062). (4) Piela: polskie wydanie na start, angielskie jako nowsze; zostaje miejsce na zdanie Adriana, dlaczego Piela. (5) Bez wskazywania serwisów z cudzymi notatkami.
**Dlaczego:** decyzja zleceniodawcy z 3.11.2026.
**Odrzucone:** nic.

## D-17, 2026-11-03: wstawki na rysunki z identyfikatorami (zastępuje częściowo D-13)

**Co:** zgodnie z prośbą zleceniodawcy („jak nie ma obrazka, ale wiesz, że byłby dobry, dawaj wstawkę”) w całym kursie stoją 23 wstawki `[RYSUNEK: F-xx, typ. Opis. Podpis: „…”]`: 13 „do znalezienia” (obraz, który prawdopodobnie istnieje na wolnej licencji, np. widmo elektromagnetyczne, kształty orbitali, zestaw do miareczkowania) i 10 „do narysowania” (schematy z danymi bonusu, np. porównanie kierunku lekarskiego na trzech uczelniach). Rejestr `dane/rysunki-plan.csv` ma dla każdej wstawki opis, podpis, frazy do wyszukania, miejsce szukania i wymaganą licencję; `RYSUNKI-DO-ZNALEZIENIA.md` to ta sama lista do czytania (generowana skryptem `rysunki_md.py`). `sprawdz.py` pilnuje zgodności wstawek z rejestrem.
**Dlaczego:** agent od obrazków dostaje jedną listę z wszystkim, czego potrzebuje, a wstawki w tekście mówią, gdzie co ma stanąć. Rysunki „do narysowania” pokazują dane z sylabusów, których nigdzie indziej nie ma.
**Odrzucone:** wstawki bez identyfikatorów (trudno je śledzić), rysunki z OpenStax i LibreTexts NC.

## D-18, 2026-11-03: forma ostateczna (decyzja zleceniodawcy: „mini-kurs w formie ostatecznej”)

**Co:** (1) Miejsca `[ADRIAN]`: jedno wypełnione z życiorysu w kontekście (obie prace dyplomowe po angielsku, rozdział 1). Siedem pozostałych to prośby o anegdoty z korepetycji; agent ich nie wymyśla, więc wyjęto je z tekstu, a tekst przeredagowano tak, żeby był kompletny bez nich. Pytania z dokładnym miejscem są w `DO-UZUPELNIENIA-ADRIAN.md`. (2) Wszystkie `[SPRAWDZIĆ]` rozwiązane (checkpoint A). (3) Redakcja końcowa: usunięte z opisów cechy stylu filmów i książek, których nie sprawdzono (np. „angielski prosty i wolny”, „szybkie tempo”, „uczy przez mechanizmy”), bo opisy wideo powstały z list tytułów (D-04); w ich miejsce opis ze spisu treści albo nic. Poprawione uogólnienia bez źródła. (4) Wydanie do czytania w `wydanie/`: jeden plik Markdown bez komentarzy źródłowych, podgląd HTML i PDF. W wydaniu tytuły rozdziałów są o poziom wyżej, a cztery wprowadzenia stoją pod wspólnym tytułem „Rzeczy, które spotka prawie każdy”. Rozdziały w `tresc/` zostają źródłem prawdy; wydanie generuje `skrypty/wydanie.py` i `skrypty/pdf.js`. (5) Wstawki `[RYSUNEK]` zostają w wydaniu do czasu pracy agenta od obrazków (D-17).
**Dlaczego:** zleceniodawca chce gotowego tekstu; anegdot z jego korepetycji nie da się uzupełnić bez niego, ale tekst bez nich jest pełny.
**Odrzucone:** wymyślanie przykładów z korepetycji; zostawienie pustych wstawek `[ADRIAN]` w tekście końcowym.
