## Co z matury zamienia się w co

Kurs KaNaU 50/70/90 przeprowadził Cię przez 20 modułów, od budowy atomu po cukry. Nic z tego nie przepada. Na studiach ten sam materiał wraca, tylko w innych przedmiotach, pod innymi nazwami i z dodatkami, których na maturze nie było. Ten rozdział pokazuje, gdzie konkretnie.

Mapa powstała z 22 publicznych sylabusów i planów studiów na ośmiu kierunkach, głównie z lat 2024/25–2026/27. Sylabus, czyli karta przedmiotu, to publiczny opis: jakie są treści, ile godzin, jak się zalicza i z czego się uczyć. Każda wymieniona uczelnia jest przykładem, a nie regułą. Na Twojej uczelni będzie trochę inaczej, i o tym jest druga część rozdziału.

### Jak czytać tę mapę

W pierwszej kolumnie jest moduł kursu. W drugiej przedmiot pierwszego roku, w którym ten materiał wraca, z przykładem uczelni. W trzeciej to, co dochodzi nowego. Odnośniki w nawiasach kwadratowych prowadzą do listy źródeł w rozdziale 5.

Dwie rzeczy warto wiedzieć z góry. Po pierwsze, nazwy przedmiotów się różnią: chemię ogólną i nieorganiczną na jednej uczelni nazywa się „Chemia ogólna i nieorganiczna”, na innej „Podstawy chemii”, na kierunku lekarskim bywa częścią „Biochemii z elementami chemii”. Po drugie, ECTS to punkty przypisane do przedmiotu, mierzące, ile pracy wymaga; semestr to 30 punktów. Liczba punktów mówi więc, jak duży jest przedmiot.

| Moduł kursu | Gdzie wraca na pierwszym roku (przykłady) | Co dochodzi nowego |
|---|---|---|
| I. Budowa atomu | chemia ogólna: „Podstawy chemii” na chemii UJ [Z-003], „Chemia ogólna” na chemii UW [Z-004], chemia ogólna i nieorganiczna na farmacji WUM [Z-015] | kwantowy opis atomu: równanie Schrödingera dla atomu wodoru, liczby kwantowe wyprowadzone, a nie podane [Z-003]; rozdział 4b |
| II. Wiązania i oddziaływania | chemia ogólna [Z-003] [Z-015] [Z-021] | orbitale molekularne jako kombinacje orbitali atomowych, hybrydyzacja jako narzędzie opisu, symetria cząsteczek, sieć krystaliczna i teoria pasmowa [Z-003] |
| III. Systematyka związków nieorganicznych | chemia ogólna i nieorganiczna, potem chemia nieorganiczna (na technologii chemicznej PW w drugim semestrze) [Z-019] [Z-023]; na technologii chemicznej PP druga część przedmiotu w drugim semestrze [Z-024] | chemia pierwiastków grupa po grupie [Z-015] [Z-017], związki kompleksowe z nazewnictwem i trwałością [Z-014] [Z-016] |
| IV. Stechiometria | ćwiczenia rachunkowe z chemii ogólnej [Z-017] [Z-019] [Z-021] | stężenie normalne i gramorównoważnik [Z-021], ułamek molowy [Z-019], znacznie więcej zadań i szybsze tempo |
| V. Kinetyka, statyka, energetyka | chemia ogólna, później chemia fizyczna (na PW w trzecim semestrze) [Z-003] [Z-021] [Z-023] | entropia, energia Gibbsa, potencjał chemiczny, wykresy fazowe; reakcje pierwszego i drugiego rzędu, równania Arrheniusa i Eyringa [Z-021] |
| VI. Roztwory | chemia ogólna [Z-019]; na weterynarii UP Lublin w „Chemii” pierwszego semestru, razem z pH, buforami i redoksem [Z-012] [Z-013]; na stomatologii UMB w przedmiocie „Chemia zintegrowana z materiałoznawstwem” [Z-010] | roztwory koloidalne [Z-014], molekularna interpretacja rozpuszczania [Z-019], iloczyn rozpuszczalności [Z-010] |
| VII. pH i reakcje w roztworach elektrolitów | chemia ogólna i nieorganiczna [Z-014] [Z-016] [Z-021]; na kierunku lekarskim UJ CM już w biochemii pierwszego roku [Z-005] | aktywność zamiast stężenia, współczynniki aktywności, siła jonowa [Z-021] [Z-022]; bufory fizjologiczne i równowaga kwasowo-zasadowa organizmu [Z-005] [Z-010]; rozdział 4a |
| VIII. Redoks | chemia ogólna [Z-003] [Z-017]; miareczkowania redoks na laboratorium [Z-019] | równanie Nernsta, potencjał normalny i warunkowy [Z-014] |
| IX. Elektrochemia | chemia ogólna [Z-003] [Z-014] [Z-016]; chemia fizyczna później | ilościowy opis ogniw i elektrolizy [Z-014] |
| X. Zastosowania związków nieorganicznych | chemia nieorganiczna, analiza jakościowa na farmacji [Z-014] [Z-015] | rola pierwiastków w organizmie [Z-010] [Z-017], izotopy promieniotwórcze w medycynie [Z-014] [Z-016], reakcje zalecane przez Farmakopeę [Z-014] |
| XI. Wstęp do chemii organicznej (obie części) | chemia organiczna: na analityce medycznej WUM na pierwszym roku [Z-018], na technologii chemicznej PW w czwartym semestrze [Z-023] | pełne nazewnictwo IUPAC, stereochemia w przestrzeni, konformacje; rozdział 3 |
| XII. Węglowodory | chemia organiczna [Z-018] [Z-023] | mechanizmy reakcji rysowane strzałkami, karbokationy, stabilność produktów |
| XIII. Alkohole i fenole | chemia organiczna | mechanizmy substytucji i eliminacji |
| XIV. Aldehydy i ketony | chemia organiczna | addycja nukleofilowa do grupy karbonylowej, enole i enolany |
| XV. Kwasy karboksylowe | chemia organiczna | kwasowość tłumaczona budową cząsteczki, pochodne kwasów i ich przemiany |
| XVI. Estry i tłuszcze | chemia organiczna, biochemia | mechanizm estryfikacji i hydrolizy; lipidy w błonach komórkowych |
| XVII. Związki zawierające azot | chemia organiczna, biochemia | aminy jako zasady i nukleofile, heterocykle |
| XVIII. Białka | biochemia: na kierunku lekarskim UJ CM i UMB na pierwszym roku [Z-005] [Z-007], na weterynarii SGGW w pierwszym semestrze [Z-011], na lekarskim WUM na drugim roku [Z-006] | enzymy i ich kinetyka, synteza białek, metody laboratoryjne biochemii [Z-005] |
| XIX. Cukry | biochemia [Z-005] [Z-011] | metabolizm: glikoliza, cykl Krebsa, łańcuch oddechowy |

[SPRAWDZIĆ: wiersze XII–XVII opierają się na spisie przedmiotów (Z-018, Z-023), bez szczegółowych treści sylabusów chemii organicznej pierwszego roku; „co dochodzi” jest wzięte z typowego podręcznika (R-016, rozdziały odpowiednich grup) i warto je potwierdzić sylabusem organicznej przy wydaniu.]

### Rzeczy, których na maturze nie było wcale

Cztery tematy z tabeli są zupełnie nowe i pojawiają się na wielu kierunkach. Mają osobne krótkie wprowadzenia w rozdziale 4.

Aktywność, czyli „skuteczne stężenie” jonów w roztworze, pada już w pierwszym semestrze chemii ogólnej i nieorganicznej na przykład na Politechnice Poznańskiej, na technologii chemicznej i na inżynierii chemicznej i procesowej [Z-021] [Z-022]. Więcej w rozdziale 4a.

Chemia kwantowa wchodzi na kierunku chemia od razu: „Podstawy chemii” w pierwszym semestrze na UJ obejmują równanie Schrödingera dla atomu wodoru i orbitale molekularne [Z-003], a chemia ogólna na UW „elementy kwantowego opisu mikroświata” [Z-004]. Na farmacji WUM wykład zaczyna się od „mechaniczno-kwantowej teorii atomu” [Z-015]. Więcej w rozdziale 4b.

Spektroskopia na pierwszym roku pojawia się na przykład w laboratorium, jako oznaczanie fosforanów metodą krzywej wzorcowej na biotechnologii UKSW [Z-019]. Na kierunkach chemicznych wraca w organicznej i analityce na kolejnych latach. Więcej w rozdziale 4c.

Laboratorium jest na pierwszym roku prawie wszędzie, a jego zasady są nową grą: wejściówki, czyli krótkie sprawdziany przed ćwiczeniem, sprawozdania, czyli pisemne opracowania wykonanych ćwiczeń, i zeszyt laboratoryjny. Więcej w rozdziale 4d.

### Ten sam przedmiot, inna treść

Na maturze wszyscy uczą się z tej samej podstawy programowej. Na studiach przedmiot o tej samej nazwie potrafi wyglądać zupełnie inaczej, bo każda uczelnia układa go po swojemu i pod swój kierunek. Trzy przykłady z zebranych sylabusów.

Pierwszy przykład to jedna uczelnia i jedna nazwa. „Chemia ogólna i nieorganiczna” w pierwszym semestrze Politechniki Poznańskiej ma na technologii chemicznej 45 godzin wykładu, 30 godzin ćwiczeń i 7 punktów ECTS [Z-021]. Na inżynierii chemicznej i procesowej ta sama nazwa oznacza 30 godzin wykładu, 30 godzin ćwiczeń i 5 punktów [Z-022]. Plan wykładu jest podobny, ale na technologii chemicznej godzin wykładu jest o połowę więcej.

Drugi przykład to ta sama nazwa na trzech kierunkach. „Chemia ogólna i nieorganiczna” w pierwszym semestrze farmacji UJ CM ma 7 punktów i obejmuje między innymi reakcje identyfikacji jonów zalecane przez Farmakopeę Polską i Europejską [Z-014]. Na analityce medycznej Uniwersytetu Medycznego w Łodzi ma 4 punkty, 15 godzin wykładu i 35 godzin laboratorium, a wykład przechodzi przez chemię pierwiastków bloków s, p i d [Z-017]. Na biotechnologii Uniwersytetu Rzeszowskiego to 30 godzin wykładu, 30 godzin laboratorium i 6 punktów [Z-020]. Ta sama nazwa, trzy różne zestawy rzeczy do umienia.

Trzeci przykład dotyczy tego, czy chemia w ogóle jest na pierwszym roku. Na kierunku lekarskim Warszawskiego Uniwersytetu Medycznego w programie pierwszego roku 2025/26 nie ma przedmiotu chemicznego; chemia przychodzi na drugim roku jako „Biochemia z elementami chemii”, 180 godzin i 17 punktów [Z-006]. W Uniwersytecie Medycznym w Białymstoku na pierwszym roku są osobno „Chemia” (30 godzin, 2 punkty) i „Biochemia” (145 godzin, 11 punktów) [Z-007]. Na UJ CM pierwszy rok kierunku lekarskiego ma biochemię przez dwa semestry, a jej pierwsze zajęcia dotyczą wody, równowag jonowych i pH buforów, czyli chemii z matury [Z-005]. Na stomatologii jest podobnie: na UJ CM chemia pojawia się dopiero na drugim roku [Z-008], w UMB na pierwszym, jako 20 godzin „Chemii zintegrowanej z materiałoznawstwem” [Z-009] [Z-010].

Z tych przykładów nie da się zgadnąć, jak będzie u Ciebie. Da się za to zrobić jedną rzecz: gdy znasz już swoją uczelnię, znaleźć sylabusy swoich przedmiotów. Jak to zrobić i na co w nich patrzeć, jest w rozdziale 1.

[ADRIAN: tu jedno zdanie z Twojego doświadczenia z korepetycji, jeśli pasuje, np. przykład studenta, którego zaskoczyło, że przedmiot o znanej nazwie wyglądał zupełnie inaczej niż u kolegi z innej uczelni.]
